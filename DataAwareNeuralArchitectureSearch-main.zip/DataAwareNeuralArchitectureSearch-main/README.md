# tinyMLInputModelOptimization
A repository for my research experiments concering optimising machine learning input and model simultaneously.
